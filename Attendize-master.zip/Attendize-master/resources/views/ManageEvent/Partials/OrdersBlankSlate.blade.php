@extends('Shared.Layouts.BlankSlate')


@section('blankslate-icon-class')
    ico-cart
@stop

@section('blankslate-title')
    @lang("ManageEvent.no_orders_yet")
@stop

@section('blankslate-text')
    @lang("ManageEvent.no_orders_yet_text")
@stop

@section('blankslate-body')

@stop

