@extends('Shared.Layouts.Master')

@section('title')
@parent
@lang("ManageAccount.event_attendees")
@stop


@section('page_title')
<i class="ico-users"></i>
@lang("ManageAccount.account_payment")
@stop