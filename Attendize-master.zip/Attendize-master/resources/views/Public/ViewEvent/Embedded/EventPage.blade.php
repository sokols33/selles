@extends('Public.ViewEvent.Layouts.EmbeddedEventPage')

@section('content')
    @include('Public.ViewEvent.Partials.EventTicketsSection')
    @include('Public.ViewEvent.Embedded.Partials.PoweredByEmbedded')
@stop