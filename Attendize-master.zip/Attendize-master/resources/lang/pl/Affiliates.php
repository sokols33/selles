<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:14:11 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'affiliate_name' => 'Nazwa Wspólnika',
  'affiliate_tracking' => 'Statystki Wspólników',
  'affiliate_tracking_text' => 'Śledzenie danych na temat tego, kto generuje ci sprzedaże jest bardzo proste! Utwórz link referencyjny korzystając z pola niżej i upostępnij wygenerowany link wspólnikom / reklamodawcom.',
  'last_referral' => 'Ostatnia referencja',
  'no_affiliate_referrals_yet' => 'Nie ma jeszcze linków referencyjnych',
  'sales_volume_generated' => 'Wygenerowana sprzedaż',
  'ticket_sales_generated' => 'Wygenerowane bilety',
  'visits_generated' => 'Wygenerowane wizyty',
);