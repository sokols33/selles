<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 18:57:21 
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'this_event_has_started' => 'To wydarzenie już się rozpoczęło.',
    //==================================== Translations ====================================//
    'create_tickets' => 'Utwórz bilety',
    'edit_event_page_design' => 'Edytuj Wygląd Strony Wydarzenia',
    'edit_organiser_fees' => 'Edytuj Opłaty Organizatora',
    'event_page_visits' => 'Odwiedziny Na Stronie Wydarzenia',
    'event_url' => 'URL Wydarzenia',
    'event_views' => 'Wyświetlenia Wydarzenia',
    'generate_affiliate_link' => 'Wygeneruj Link Referencyjny',
    'orders' => 'Zamówienia',
    'quick_links' => 'Skróty',
    'registrations_by_ticket' => 'Rejestracji na bilet',
    'sales_volume' => 'Sprzedaż',
    'share_event' => 'Udostępnij Wydarzenie',
    'this_event_is_on_now' => 'To wydarzenie odbywa się teraz',
    'ticket_sales_volume' => 'Sprzedaż biletów',
    'tickets_sold' => 'Sprzedanych biletów',
    'website_embed_code' => 'Kod do wklejenia na stronę',
);