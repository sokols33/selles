<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/18 16:23:42 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Partials\\SurveyBlankSlate.blade.php
  'create_question' => 'Utwórz Pytanie',
  //==================================== Translations ====================================//
  'Q' => 'P',
  'add_another_option' => 'Dodaj opcję',
  'answer' => 'Odpowiedź',
  'attendee_details' => 'Uczestnik',
  'make_this_a_required_question' => 'Pytanie wymagane',
  'no_answers' => 'Nie ma jeszcze odpowiedzi na to pytanie.',
  'no_questions_yet' => 'Brak Pytań',
  'no_questions_yet_text' => 'Tutaj możesz dodać pytania, na które uczestnicy mogą odpowiedzieć w trakcie procesu finalizacji zamówienia.',
  'question' => 'Pytanie',
  'question_options' => 'Opcje Pytania',
  'question_placeholder' => 'np. Podaj swój pełny adres?',
  'question_type' => 'Typ pytania',
  'require_this_question_for_ticket(s)' => 'Wymagaj pytania do bilet(ów)',
);