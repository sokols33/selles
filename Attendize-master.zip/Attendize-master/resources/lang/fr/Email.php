<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Merci de votre inscription à Attendize',
  'invite_user' => ':name vous a ajouté à un compte :app',
  'message_regarding_event' => 'Message au sujet de : :event',
  'organiser_copy' => '[Copie Organisateur]',
  'refund_from_name' => 'Vous avez reçu un remboursement de :name',
  'your_ticket_cancelled' => 'Votre billet a été annulé',
  'your_ticket_for_event' => 'Votre billet pour l\'événement :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
