<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/23 14:17:14 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\OrganiserSocialSection.blade.php
  'pinterest' => 'Pinterest',
  //==================================== Translations ====================================//
  'email' => 'Courriel',
  'facebook' => 'Facebook',
  'g+' => 'Google+',
  'linkedin' => 'LinkedIn',
  'share_buttons_to_show' => 'Boutons de partage à montrer',
  'social_settings' => 'Paramètres sociaux',
  'social_share_text' => 'Texte pour le partage',
  'social_share_text_help' => 'C\'est le texte qui sera par défaut partagé lorsqu\'un utilisateur partage votre événement sur les réseaux sociaux',
  'twitter' => 'Twitter',
  'whatsapp' => 'WhatsApp',
);
