<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Surveys.blade.php
  'question_delete' => 'Question Delete',
  //==================================== Translations ====================================//
  'add_question' => 'Add Question',
  'answers' => 'Answers',
  'event_surveys' => 'Event Surveys',
  'export_answers' => 'Export Answers',
  'num_responses' => '# Responses',
  'question_delete_title' => 'All answers will also be deleted. If you want to keep attendee\'s answers you should deactivate the question instead.',
  'question_title' => 'Question Title',
  'required' => 'Required',
  'status' => 'Status',
  'tickets_list' => 'Tickets: :list',
);