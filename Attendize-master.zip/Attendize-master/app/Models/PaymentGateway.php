<?php

namespace App\Models;

/**
 * Class PaymentGateway
 * @package App\Models
 */
class PaymentGateway extends MyBaseModel
{


}
