<?php
namespace App\Models;


class Country extends \Illuminate\Database\Eloquent\Model
{

}